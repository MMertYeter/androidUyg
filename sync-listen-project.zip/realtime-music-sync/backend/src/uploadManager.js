const fs = require("fs");
const path = require("path");
const multer = require("multer");
const { v4: uuidv4 } = require("uuid");
const logger = require("./logger");

const UPLOAD_ROOT = path.join(__dirname, "..", "uploads");

if (!fs.existsSync(UPLOAD_ROOT)) {
  fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
}

function roomDir(roomCode) {
  return path.join(UPLOAD_ROOT, roomCode);
}

function ensureRoomDir(roomCode) {
  const dir = roomDir(roomCode);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

/** Deletes every file currently sitting in a room's upload directory. */
function clearRoomUploads(roomCode) {
  const dir = roomDir(roomCode);
  if (!fs.existsSync(dir)) return;
  for (const file of fs.readdirSync(dir)) {
    try {
      fs.unlinkSync(path.join(dir, file));
      logger.info(`Deleted stale upload: ${roomCode}/${file}`);
    } catch (err) {
      logger.warn(`Failed to delete upload ${roomCode}/${file}:`, err.message);
    }
  }
}

function deleteRoomDir(roomCode) {
  const dir = roomDir(roomCode);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
    logger.info(`Removed upload directory for room ${roomCode}`);
  }
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const roomCode = req.params.roomCode?.toUpperCase();
    if (!roomCode) return cb(new Error("roomCode required"));
    // A room may only ever have ONE active shared file. Wipe any previous
    // upload first so the server never accumulates orphaned audio files.
    clearRoomUploads(roomCode);
    cb(null, ensureRoomDir(roomCode));
  },
  filename: (req, file, cb) => {
    const safeExt = path.extname(file.originalname).slice(0, 10);
    const uniqueName = `${uuidv4()}${safeExt}`;
    cb(null, uniqueName);
  },
});

const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB safety cap

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE_BYTES },
  fileFilter: (req, file, cb) => {
    const allowed = /\.(mp3|m4a|aac|wav|ogg|flac|opus)$/i;
    if (!allowed.test(file.originalname)) {
      return cb(new Error("Unsupported audio file type"));
    }
    cb(null, true);
  },
});

/** Express route handler: serves an audio file with HTTP Range support so
 * ExoPlayer clients can start playback before the whole file is fetched. */
function streamHandler(req, res) {
  const { roomCode, filename } = req.params;
  const filePath = path.join(roomDir(roomCode.toUpperCase()), filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "File not found (it may have been cleaned up)" });
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  const ext = path.extname(filePath).toLowerCase();
  const mimeMap = {
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".wav": "audio/wav",
    ".ogg": "audio/ogg",
    ".flac": "audio/flac",
    ".opus": "audio/opus",
  };
  const contentType = mimeMap[ext] || "application/octet-stream";

  if (range) {
    const parts = range.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunkSize = end - start + 1;

    res.writeHead(206, {
      "Content-Range": `bytes ${start}-${end}/${fileSize}`,
      "Accept-Ranges": "bytes",
      "Content-Length": chunkSize,
      "Content-Type": contentType,
    });
    fs.createReadStream(filePath, { start, end }).pipe(res);
  } else {
    res.writeHead(200, {
      "Content-Length": fileSize,
      "Content-Type": contentType,
      "Accept-Ranges": "bytes",
    });
    fs.createReadStream(filePath).pipe(res);
  }
}

module.exports = {
  upload,
  streamHandler,
  clearRoomUploads,
  deleteRoomDir,
  UPLOAD_ROOT,
};
