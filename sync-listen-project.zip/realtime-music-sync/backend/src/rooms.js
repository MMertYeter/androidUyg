const { v4: uuidv4 } = require("uuid");
const logger = require("./logger");

/**
 * In-memory room store.
 *
 * IMPORTANT DESIGN DECISION (resilient rooms):
 * A room is NEVER destroyed just because a socket disconnects (host or guest).
 * Sockets disconnect all the time on mobile (screen off, background, network drop).
 * The room only dies when:
 *   1) The host explicitly sends "close_room", or
 *   2) The room has had zero connected clients for IDLE_TTL_MS (safety-net GC so
 *      memory doesn't grow forever on a long-running server), or
 *   3) The whole Node process restarts / sleeps (Render free tier) - which wipes
 *      all in-memory state anyway, that's expected and communicated to the user.
 *
 * Clients are identified by a persistent `clientId` (UUID generated once on the
 * Android device and stored locally), NOT by socket.id, because socket.id changes
 * every time a client reconnects. This is what allows seamless reconnection.
 */

const IDLE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours with nobody connected -> GC
const GC_SWEEP_INTERVAL_MS = 10 * 60 * 1000; // sweep every 10 minutes

class RoomManager {
  constructor() {
    /** @type {Map<string, Room>} */
    this.rooms = new Map();
    this._gcTimer = setInterval(() => this._sweep(), GC_SWEEP_INTERVAL_MS);
    this._gcTimer.unref?.();
  }

  _sweep() {
    const now = Date.now();
    for (const [code, room] of this.rooms.entries()) {
      const anyoneConnected = [...room.clients.values()].some((c) => c.connected);
      if (!anyoneConnected && now - room.emptySince > IDLE_TTL_MS) {
        logger.info(`GC: destroying idle empty room ${code}`);
        this.rooms.delete(code);
      }
    }
  }

  _generateRoomCode() {
    // 5-character, human-friendly (no ambiguous chars like 0/O, 1/I)
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code;
    do {
      code = Array.from({ length: 5 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
    } while (this.rooms.has(code));
    return code;
  }

  createRoom(hostClientId, hostName) {
    const code = this._generateRoomCode();
    /** @type {Room} */
    const room = {
      code,
      hostClientId,
      createdAt: Date.now(),
      emptySince: 0,
      clients: new Map(), // clientId -> { socketId, name, isHost, connected }
      playback: {
        source: null, // 'local' | 'youtube' | 'spotify'
        sourceMeta: null, // { fileUrl, filename } | { videoId } | { uri, name, artist }
        isPlaying: false,
        positionMs: 0,
        lastUpdateTimestamp: Date.now(),
      },
      currentUpload: null, // { filePath, filename } - tracked for auto-cleanup
    };
    room.clients.set(hostClientId, {
      socketId: null,
      name: hostName || "Host",
      isHost: true,
      connected: false,
    });
    this.rooms.set(code, room);
    logger.info(`Room created: ${code} by host ${hostClientId}`);
    return room;
  }

  getRoom(code) {
    return this.rooms.get(code?.toUpperCase());
  }

  /**
   * Called on join_room (works for both first join AND reconnection, since it's
   * upsert-by-clientId).
   */
  joinRoom(code, clientId, name, socketId) {
    const room = this.getRoom(code);
    if (!room) return null;

    const existing = room.clients.get(clientId);
    if (existing) {
      existing.socketId = socketId;
      existing.connected = true;
      if (name) existing.name = name;
    } else {
      room.clients.set(clientId, {
        socketId,
        name: name || "Guest",
        isHost: false,
        connected: true,
      });
    }
    room.emptySince = 0;
    return room;
  }

  markDisconnected(code, clientId) {
    const room = this.getRoom(code);
    if (!room) return;
    const client = room.clients.get(clientId);
    if (client) {
      client.connected = false;
      client.socketId = null;
    }
    const anyoneConnected = [...room.clients.values()].some((c) => c.connected);
    if (!anyoneConnected) {
      room.emptySince = Date.now();
    }
  }

  leaveRoomPermanently(code, clientId) {
    const room = this.getRoom(code);
    if (!room) return;
    room.clients.delete(clientId);
  }

  closeRoom(code) {
    const room = this.getRoom(code);
    if (!room) return null;
    this.rooms.delete(code);
    logger.info(`Room closed: ${code}`);
    return room;
  }

  isHost(code, clientId) {
    const room = this.getRoom(code);
    return !!room && room.hostClientId === clientId;
  }

  /**
   * Updates playback state and returns the new state snapshot.
   * positionMs is the position AT THE MOMENT this update was issued (client-reported).
   */
  updatePlayback(code, { isPlaying, positionMs, source, sourceMeta }) {
    const room = this.getRoom(code);
    if (!room) return null;
    if (typeof isPlaying === "boolean") room.playback.isPlaying = isPlaying;
    if (typeof positionMs === "number") room.playback.positionMs = positionMs;
    if (source !== undefined) room.playback.source = source;
    if (sourceMeta !== undefined) room.playback.sourceMeta = sourceMeta;
    room.playback.lastUpdateTimestamp = Date.now();
    return this.getPlaybackSnapshot(code);
  }

  /**
   * Returns the playback state with position EXTRAPOLATED to "now" if playing,
   * so a freshly (re)joining client can seek straight to the correct live position.
   */
  getPlaybackSnapshot(code) {
    const room = this.getRoom(code);
    if (!room) return null;
    const { isPlaying, positionMs, lastUpdateTimestamp, source, sourceMeta } = room.playback;
    let extrapolatedPosition = positionMs;
    if (isPlaying) {
      extrapolatedPosition = positionMs + (Date.now() - lastUpdateTimestamp);
    }
    return {
      source,
      sourceMeta,
      isPlaying,
      positionMs: extrapolatedPosition,
      serverTime: Date.now(),
    };
  }

  getRoomSummary(code) {
    const room = this.getRoom(code);
    if (!room) return null;
    return {
      code: room.code,
      hostClientId: room.hostClientId,
      members: [...room.clients.entries()].map(([clientId, c]) => ({
        clientId,
        name: c.name,
        isHost: c.isHost,
        connected: c.connected,
      })),
      playback: this.getPlaybackSnapshot(code),
    };
  }

  setCurrentUpload(code, uploadInfo) {
    const room = this.getRoom(code);
    if (!room) return;
    room.currentUpload = uploadInfo;
  }

  getCurrentUpload(code) {
    const room = this.getRoom(code);
    return room?.currentUpload || null;
  }
}

module.exports = { RoomManager, generateClientId: uuidv4 };
