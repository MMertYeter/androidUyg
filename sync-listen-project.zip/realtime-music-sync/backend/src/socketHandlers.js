const logger = require("./logger");
const { clearRoomUploads, deleteRoomDir } = require("./uploadManager");

/**
 * @param {import('socket.io').Server} io
 * @param {import('./rooms').RoomManager} roomManager
 */
function registerSocketHandlers(io, roomManager) {
  io.on("connection", (socket) => {
    logger.info(`Socket connected: ${socket.id}`);

    // ---- CREATE ROOM ----
    socket.on("create_room", ({ clientId, name }, ack) => {
      try {
        if (!clientId) return ack?.({ ok: false, error: "clientId required" });
        const room = roomManager.createRoom(clientId, name);
        const joined = roomManager.joinRoom(room.code, clientId, name, socket.id);
        socket.join(room.code);
        socket.data.roomCode = room.code;
        socket.data.clientId = clientId;
        ack?.({ ok: true, room: roomManager.getRoomSummary(room.code) });
      } catch (err) {
        logger.error("create_room failed:", err);
        ack?.({ ok: false, error: "Could not create room" });
      }
    });

    // ---- JOIN (also used for RE-JOIN after reconnect) ----
    socket.on("join_room", ({ roomCode, clientId, name }, ack) => {
      try {
        if (!roomCode || !clientId) {
          return ack?.({ ok: false, error: "roomCode and clientId required" });
        }
        const room = roomManager.joinRoom(roomCode, clientId, name, socket.id);
        if (!room) {
          return ack?.({ ok: false, error: "Room not found. It may have been closed." });
        }
        socket.join(room.code);
        socket.data.roomCode = room.code;
        socket.data.clientId = clientId;

        const summary = roomManager.getRoomSummary(room.code);
        ack?.({ ok: true, room: summary });

        // Let everyone else in the room know who (re)joined.
        socket.to(room.code).emit("member_update", summary.members);
      } catch (err) {
        logger.error("join_room failed:", err);
        ack?.({ ok: false, error: "Could not join room" });
      }
    });

    // ---- EXPLICIT LEAVE (guest chose to leave, not just a network drop) ----
    socket.on("leave_room", ({ roomCode, clientId }) => {
      if (!roomCode || !clientId) return;
      roomManager.leaveRoomPermanently(roomCode, clientId);
      socket.leave(roomCode);
      const summary = roomManager.getRoomSummary(roomCode);
      if (summary) {
        io.to(roomCode).emit("member_update", summary.members);
      }
    });

    // ---- CLOSE ROOM (host only) ----
    socket.on("close_room", ({ roomCode, clientId }, ack) => {
      if (!roomManager.isHost(roomCode, clientId)) {
        return ack?.({ ok: false, error: "Only the host can close the room" });
      }
      io.to(roomCode).emit("room_closed");
      roomManager.closeRoom(roomCode);
      deleteRoomDir(roomCode);
      io.socketsLeave(roomCode);
      ack?.({ ok: true });
    });

    // ---- SET SOURCE (host picks a YouTube video / Spotify track / local file) ----
    socket.on("set_source", ({ roomCode, clientId, source, sourceMeta, positionMs }, ack) => {
      if (!roomManager.isHost(roomCode, clientId)) {
        return ack?.({ ok: false, error: "Only the host can change the source" });
      }
      // Switching away from a local file cleans up the old upload immediately.
      const room = roomManager.getRoom(roomCode);
      if (room?.playback.source === "local" && source !== "local") {
        clearRoomUploads(roomCode);
      }
      const snapshot = roomManager.updatePlayback(roomCode, {
        source,
        sourceMeta,
        positionMs: positionMs ?? 0,
        isPlaying: false,
      });
      io.to(roomCode).emit("playback_state", snapshot);
      ack?.({ ok: true });
    });

    // ---- PLAYBACK CONTROL: play / pause / seek ----
    socket.on("playback_control", ({ roomCode, clientId, action, positionMs }) => {
      if (!roomManager.isHost(roomCode, clientId)) return; // only host drives playback
      let isPlaying;
      if (action === "play") isPlaying = true;
      else if (action === "pause") isPlaying = false;
      // 'seek' doesn't change isPlaying, just position + timestamp

      const snapshot = roomManager.updatePlayback(roomCode, {
        isPlaying,
        positionMs,
      });
      if (snapshot) {
        io.to(roomCode).emit("playback_state", snapshot);
      }
    });

    // ---- TRACK ENDED (host signals natural end, e.g. to clear local file) ----
    socket.on("playback_ended", ({ roomCode, clientId }) => {
      if (!roomManager.isHost(roomCode, clientId)) return;
      const room = roomManager.getRoom(roomCode);
      if (room?.playback.source === "local") {
        clearRoomUploads(roomCode);
      }
      const snapshot = roomManager.updatePlayback(roomCode, {
        isPlaying: false,
        positionMs: 0,
      });
      io.to(roomCode).emit("playback_state", snapshot);
    });

    // ---- LATENCY MEASUREMENT ----
    socket.on("sync_ping", (clientSentAt) => {
      socket.emit("sync_pong", { clientSentAt, serverTime: Date.now() });
    });

    // ---- DISCONNECT (network drop, backgrounding, screen off, etc.) ----
    socket.on("disconnect", (reason) => {
      const { roomCode, clientId } = socket.data;
      logger.info(`Socket disconnected: ${socket.id} (${reason})`);
      if (roomCode && clientId) {
        roomManager.markDisconnected(roomCode, clientId);
        const summary = roomManager.getRoomSummary(roomCode);
        if (summary) {
          socket.to(roomCode).emit("member_update", summary.members);
        }
      }
    });
  });
}

module.exports = { registerSocketHandlers };
