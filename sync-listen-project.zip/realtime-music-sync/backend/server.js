require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const logger = require("./src/logger");
const { RoomManager } = require("./src/rooms");
const { registerSocketHandlers } = require("./src/socketHandlers");
const { upload, streamHandler } = require("./src/uploadManager");

const PORT = process.env.PORT || 3000;

const app = express();
app.use(cors({ origin: "*" }));
app.use(express.json());

const roomManager = new RoomManager();

// ---- Health check (also what keeps Render happy / lets you verify deploys) ----
app.get("/health", (req, res) => {
  res.json({ ok: true, rooms: roomManager.rooms.size, uptime: process.uptime() });
});

// ---- Upload a local audio file for a room (host only, enforced by clientId check) ----
app.post("/api/upload/:roomCode", (req, res) => {
  const { roomCode } = req.params;
  const { clientId } = req.query;

  if (!roomManager.isHost(roomCode, clientId)) {
    return res.status(403).json({ error: "Only the host can upload a file" });
  }

  upload.single("audio")(req, res, (err) => {
    if (err) {
      logger.error("Upload failed:", err.message);
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: "No file received" });
    }
    const fileUrl = `/stream/${roomCode.toUpperCase()}/${req.file.filename}`;
    roomManager.setCurrentUpload(roomCode, {
      filePath: req.file.path,
      filename: req.file.filename,
    });
    logger.info(`Upload complete for room ${roomCode}: ${req.file.filename} (${req.file.size} bytes)`);
    res.json({ ok: true, fileUrl, filename: req.file.originalname });
  });
});

// ---- Stream the currently shared file (Range-request aware, for ExoPlayer) ----
app.get("/stream/:roomCode/:filename", streamHandler);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
  // Ping settings tuned to detect drops reasonably fast without being trigger-happy
  // on flaky mobile networks (helps distinguish "true disconnect" from a brief blip).
  pingInterval: 10000,
  pingTimeout: 15000,
});

registerSocketHandlers(io, roomManager);

server.listen(PORT, () => {
  logger.info(`Sync-Listen backend running on port ${PORT}`);
});

// Basic process-level safety nets so one bad request never kills the server.
process.on("unhandledRejection", (err) => logger.error("Unhandled rejection:", err));
process.on("uncaughtException", (err) => logger.error("Uncaught exception:", err));
