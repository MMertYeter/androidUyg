# SyncListen - Kurulum Rehberi

Bu depo iki bağımsız proje içerir:

```
realtime-music-sync/
  backend/    -> Node.js + Express + Socket.io sunucusu (Render.com'a deploy edilir)
  android/    -> Android uygulaması (Kotlin + Jetpack Compose)
```

---

## 1) Backend'i Render.com'a Deploy Etme

### 1.1 Yerelde test (opsiyonel ama önerilir)
```bash
cd backend
npm install
npm start
```
Sonra tarayıcıda `http://localhost:3000/health` adresine gidip `{"ok":true,...}` görmelisin.

### 1.2 GitHub'a yükle
```bash
cd backend
git init
git add .
git commit -m "İlk commit"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/sync-listen-backend.git
git push -u origin main
```

### 1.3 Render.com'da servis oluştur
1. https://render.com adresine git, GitHub hesabınla giriş yap.
2. **New +** → **Web Service** → yukarıda push ettiğin repoyu seç.
3. Render, repodaki `render.yaml` dosyasını otomatik algılar. Algılamazsa manuel ayarlar:
   - **Environment:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free
4. **Create Web Service**'e tıkla. Birkaç dakika içinde şu formatta bir URL alacaksın:
   `https://sync-listen-backend-xxxx.onrender.com`
5. Bu URL'i not al — Android tarafında `Prefs.DEFAULT_SERVER_URL` içine (veya uygulama içindeki "Sunucu adresi" alanına) gireceksin.

### 1.4 Render Free Plan hakkında bilinmesi gerekenler
- Free plan'da servis **15 dakika** trafik almazsa uykuya geçer. Bir sonraki istek geldiğinde ~30-50 saniye içinde uyanır (bu sırada odalar da hafızadan silinmiş olur, çünkü state RAM'de tutuluyor — bu normal ve beklenen bir davranıştır, ücretsiz planın doğası budur).
- Sürekli aktif kalması gerekiyorsa ücretli bir plana geçmen veya harici bir "uptime ping" servisiyle periyodik istek atman gerekir.

---

## 2) Android Uygulamasını Derleme

### 2.1 Projeyi aç
1. Android Studio'yu aç (Hedgehog/Iguana veya daha yeni bir sürüm önerilir).
2. **Open** → `android/` klasörünü seç.
3. Gradle senkronizasyonunun bitmesini bekle (ilk açılışta Gradle 8.7 ve bağımlılıklar internetten indirilecek).

### 2.2 Sunucu adresini ayarla
`android/app/src/main/java/com/syncmusic/app/util/Prefs.kt` içinde:
```kotlin
const val DEFAULT_SERVER_URL = "https://your-app-name.onrender.com"
```
satırını kendi Render URL'inle değiştir. (Uygulama içinden de "Sunucu adresi" alanına girip değiştirebilirsin, bu sadece varsayılan değer.)

### 2.3 Çalıştır
- Bir fiziksel Android cihazı (USB hata ayıklama açık) veya emülatör bağla.
- **Run ▶** butonuna bas.
- İki farklı cihazda/emülatörde çalıştırıp birinden oda oluştur, diğerinden oda koduyla katıl.

### 2.4 Release APK/AAB oluşturma
```
Build → Generate Signed Bundle / APK
```
Android Studio seni bir imzalama anahtarı (keystore) oluşturmaya veya var olanı seçmeye yönlendirecek. Play Store'a yüklemek istersen AAB, doğrudan APK olarak paylaşmak istersen APK seç.

---

## 3) Spotify Entegrasyonu Kurulumu

Spotify entegrasyonu iki parçadan oluşur: **Auth** (giriş) ve **App Remote** (oynatma kontrolü). Auth Maven Central üzerinden otomatik gelir; App Remote'u manuel indirmen gerekiyor çünkü Spotify onu bir Maven deposunda yayınlamıyor.

### 3.1 Spotify Developer Dashboard'da uygulama oluştur
1. https://developer.spotify.com/dashboard adresine git, Spotify hesabınla giriş yap.
2. **Create app** butonuna tıkla.
3. Formu doldur:
   - **App name:** SyncListen (istediğin isim)
   - **Redirect URI:** `syncmusic://callback` (tam olarak bu — projedeki `AndroidManifest.xml` ve `SpotifyConfig.kt` bununla eşleşiyor)
   - **Which API/SDKs are you planning to use?** → "Android" seçeneğini işaretle
4. Oluşturduktan sonra **Settings** sayfasına git, **Client ID**'yi kopyala.
5. Yine Settings sayfasında **Android packages** bölümüne:
   - **Package name:** `com.syncmusic.app`
   - **SHA-1 fingerprint:** aşağıdaki komutla debug keystore'undan alabilirsin:
     ```bash
     keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```
     Çıktıdaki `SHA1:` satırındaki değeri yapıştır. (Release build için kendi release keystore'unun SHA-1'ini de aynı şekilde ekle.)

### 3.2 Client ID'yi projeye ekle
`android/app/src/main/java/com/syncmusic/app/util/SpotifyConfig.kt`:
```kotlin
const val CLIENT_ID = "BURAYA_KENDI_CLIENT_ID'NI_YAPIŞTIR"
```

### 3.3 App Remote SDK'yı indir ve ekle
1. https://github.com/spotify/android-sdk/releases adresine git.
2. En son sürümdeki `.aar` dosyasını indir (örn. `spotify-app-remote-release-0.8.0.aar`).
3. Dosyayı `android/app/libs/` klasörüne kopyala.
4. `android/app/build.gradle.kts` içinde şu satırı bul ve yorumdan çıkar (kendi dosya adınla):
   ```kotlin
   implementation(files("libs/spotify-app-remote-release-0.8.0.aar"))
   ```
5. Gradle'ı yeniden senkronize et.

### 3.4 Test
- Test cihazında **Spotify uygulaması yüklü ve giriş yapılmış** olmalı (App Remote SDK, Spotify uygulamasının kendisiyle konuşur, kendi ses motorunu içermez).
- Oynatma kontrolü için **Spotify Premium** gereklidir (Spotify'ın kendi kısıtlaması).
- Oda ekranında "Spotify" sekmesinden bir şarkı linki (`https://open.spotify.com/track/...`) veya URI (`spotify:track:...`) girip dene.

---

## 4) YouTube Entegrasyonu Hakkında

YouTube tarafı ekstra bir API anahtarı **gerektirmez** — resmi YouTube IFrame Player API'sini bir WebView içinde kullanıyoruz (`assets/youtube_player.html`). Bu, YouTube içeriğini üçüncü parti bir uygulamada oynatmanın Kullanım Şartları'na uygun tek yoludur; ham sesi indirip yeniden dağıtmak (bu tür uygulamalarda sık görülen bir yaklaşım) ToS ihlalidir ve bu projede kasıtlı olarak yapılmamıştır.

**Bilinmesi gereken kısıtlama:** WebView tabanlı oynatma, uygulama arka plana alındığında işletim sistemi/WebView tarafından duraklatılabilir. Yerel dosya oynatma (ExoPlayer, foreground service içinde) tam arka plan desteğine sahipken, YouTube en iyi sonucu uygulama ön plandayken verir. Bu, kodun bir eksikliği değil, WebView tabanlı video oynatmanın platform kısıtlamasıdır.

---

## 5) Mimari Özeti (Neyin Nasıl Çalıştığı)

- **Dirençli oda:** Sunucu, kullanıcıları geçici `socket.id` yerine cihazda bir kez üretilip kalıcı olarak saklanan `clientId` (UUID) ile tanır. Bağlantı koptuğunda oda **asla** silinmez; sadece host `close_room` gönderdiğinde ya da oda 6 saat boyunca tamamen boş kalıp GC'ye takılırsa silinir.
- **Senkronizasyon:** Sunucu her playback state'i `positionMs` + `serverTime` ile yayınlar. Her cihaz, `sync_ping`/`sync_pong` ile sunucu saatiyle arasındaki farkı (offset) sürekli ölçer ve gelen state'i "şu anda gerçekte nerede olması gerektiği"ne ekstrapole eder (`SyncEngine.kt`). 350ms'den büyük sapmalarda seek atılır; playback sırasında 2.5 saniyede bir sürüklenme kontrolü yapılır.
- **Yeniden bağlanma:** Socket.io'nun kendi `reconnection` mekanizması + `join_room`'un upsert-by-clientId mantığı sayesinde, ağ kesintisinden sonra otomatik olarak eski konuma senkron şekilde geri döner.
- **Dosya yükleme/stream:** Multer diskStorage ile dosya sunucuya yazılır; `GET /stream/:roomCode/:filename` HTTP Range isteklerini destekler, böylece ExoPlayer dosyanın tamamı inmeden çalmaya başlayabilir. Host yeni bir kaynak seçtiğinde veya oda kapandığında eski dosya diskten otomatik silinir.

---

## 6) Bilinen Sınırlamalar (Dürüstçe Belirtilmesi Gerekenler)

- Render Free plan'da 15 dakika inaktivite sonrası oda state'i kaybolur (yukarıda açıklandı).
- YouTube WebView oynatması arka planda güvenilir değildir (platform kısıtlaması).
- Spotify entegrasyonu, App Remote SDK'nın kendi kısıtlamaları gereği Premium hesap ve yüklü Spotify uygulaması ister.
- Bu proje sandbox ortamında derlenip Android Studio ile gerçek bir cihazda test edilmedi (ortamda Android SDK/Gradle'a ağ erişimi yoktu) — backend tarafı tam anlamıyla uçtan uca test edildi ve doğrulandı, Android tarafı ise dikkatli elle yazım + statik tutarlılık kontrolünden geçirildi. İlk derlemede küçük düzeltmeler gerekebilir; böyle bir durumla karşılaşırsan hatayı benimle paylaşabilirsin.
